from setuptools import setup

setup(
    name="renovate_31075_sample",
    description="Sample Python package for Renovate discussion https://github.com/renovatebot/renovate/discussions/31075.",
    version="0.0.1",
    url="https://github.com/Enkidu-Aururu/31075",
    author="Ivan Latka"
)
